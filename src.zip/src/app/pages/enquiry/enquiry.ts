import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { EmailService } from '../../services/email';

@Component({
  selector: 'app-enquiry',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './enquiry.html',
  styleUrl: './enquiry.scss'
})
export class EnquiryComponent {
  enquiryForm: FormGroup;
  submitted = false;
  sendingEmail = false;

  constructor(private fb: FormBuilder, private emailService: EmailService) {
    this.enquiryForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      age: ['', [Validators.required, Validators.min(18), Validators.max(100)]],
      email: ['', [Validators.required, Validators.email]],
      district: ['', Validators.required],
      city: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
      solarInstallation: [false],
      fabricationEnquiry: [false],
      // Solar fields (conditional)
      kilowatt: [''],
      ebServiceNumber: [''],
      registeredMobile: [''],
      // Fabrication fields (conditional)
      length: [''],
      breadth: [''],
      materialType: [''],
      otherMaterial: ['']
    }, { validators: this.atLeastOneCheckboxValidator });
  }

  // Custom validator to ensure at least one checkbox is selected
  atLeastOneCheckboxValidator(group: FormGroup): { [key: string]: boolean } | null {
    const solarInstallation = group.get('solarInstallation')?.value;
    const fabricationEnquiry = group.get('fabricationEnquiry')?.value;
    return (solarInstallation || fabricationEnquiry) ? null : { atLeastOneRequired: true };
  }

  // Handle service type change to add/remove validators
  onServiceTypeChange() {
    const solarChecked = this.solarInstallation?.value;
    const fabricationChecked = this.fabricationEnquiry?.value;

    // Solar fields validation
    if (solarChecked) {
      this.enquiryForm.get('kilowatt')?.setValidators([Validators.required, Validators.min(1)]);
      this.enquiryForm.get('ebServiceNumber')?.setValidators([Validators.required]);
      this.enquiryForm.get('registeredMobile')?.setValidators([Validators.required, Validators.pattern('^[0-9]{10}$')]);
    } else {
      this.enquiryForm.get('kilowatt')?.clearValidators();
      this.enquiryForm.get('ebServiceNumber')?.clearValidators();
      this.enquiryForm.get('registeredMobile')?.clearValidators();
      this.enquiryForm.patchValue({
        kilowatt: '',
        ebServiceNumber: '',
        registeredMobile: ''
      });
    }

    // Fabrication fields validation
    if (fabricationChecked) {
      this.enquiryForm.get('length')?.setValidators([Validators.required, Validators.min(0.1)]);
      this.enquiryForm.get('breadth')?.setValidators([Validators.required, Validators.min(0.1)]);
      this.enquiryForm.get('materialType')?.setValidators([Validators.required]);
    } else {
      this.enquiryForm.get('length')?.clearValidators();
      this.enquiryForm.get('breadth')?.clearValidators();
      this.enquiryForm.get('materialType')?.clearValidators();
      this.enquiryForm.get('otherMaterial')?.clearValidators();
      this.enquiryForm.patchValue({
        length: '',
        breadth: '',
        materialType: '',
        otherMaterial: ''
      });
    }

    // Update validity
    this.enquiryForm.get('kilowatt')?.updateValueAndValidity();
    this.enquiryForm.get('ebServiceNumber')?.updateValueAndValidity();
    this.enquiryForm.get('registeredMobile')?.updateValueAndValidity();
    this.enquiryForm.get('length')?.updateValueAndValidity();
    this.enquiryForm.get('breadth')?.updateValueAndValidity();
    this.enquiryForm.get('materialType')?.updateValueAndValidity();
    this.enquiryForm.get('otherMaterial')?.updateValueAndValidity();

    // Handle "Others" material type
    const materialType = this.enquiryForm.get('materialType');
    if (materialType) {
      materialType.valueChanges.subscribe((value: string | null) => {
        if (value === 'Others') {
          this.enquiryForm.get('otherMaterial')?.setValidators([Validators.required]);
        } else {
          this.enquiryForm.get('otherMaterial')?.clearValidators();
          this.enquiryForm.patchValue({ otherMaterial: '' });
        }
        this.enquiryForm.get('otherMaterial')?.updateValueAndValidity();
      });
    }
  }

  // Getter methods for form controls
  get name() { return this.enquiryForm.get('name'); }
  get mobile() { return this.enquiryForm.get('mobile'); }
  get age() { return this.enquiryForm.get('age'); }
  get email() { return this.enquiryForm.get('email'); }
  get district() { return this.enquiryForm.get('district'); }
  get city() { return this.enquiryForm.get('city'); }
  get pincode() { return this.enquiryForm.get('pincode'); }
  get solarInstallation() { return this.enquiryForm.get('solarInstallation'); }
  get fabricationEnquiry() { return this.enquiryForm.get('fabricationEnquiry'); }
  // Solar fields
  get kilowatt() { return this.enquiryForm.get('kilowatt'); }
  get ebServiceNumber() { return this.enquiryForm.get('ebServiceNumber'); }
  get registeredMobile() { return this.enquiryForm.get('registeredMobile'); }
  // Fabrication fields
  get length() { return this.enquiryForm.get('length'); }
  get breadth() { return this.enquiryForm.get('breadth'); }
  get materialType() { return this.enquiryForm.get('materialType'); }
  get otherMaterial() { return this.enquiryForm.get('otherMaterial'); }
  get serviceType() { 
    return this.enquiryForm.errors?.['atLeastOneRequired'] && 
           (this.solarInstallation?.touched || this.fabricationEnquiry?.touched) 
           ? { invalid: true, touched: true } : null;
  }

  onSubmit() {
    this.submitted = false;
    
    if (this.enquiryForm.valid) {
      const formData = this.enquiryForm.value;
      console.log('Form Data:', formData);
      
      this.sendingEmail = true;
      
      // Send enquiry directly via EmailJS
      this.emailService.sendEnquiry(formData)
        .then((result: any) => {
          console.log('Email result:', result);
          this.sendingEmail = false;
          
          if (result.success) {
            this.submitted = true;
            alert(result.message);
            
            // Reset form after 3 seconds
            setTimeout(() => {
              this.enquiryForm.reset();
              this.enquiryForm.patchValue({
                solarInstallation: false,
                fabricationEnquiry: false
              });
              this.submitted = false;
            }, 3000);
          } else {
            alert(result.message);
          }
        })
        .catch((error: any) => {
          console.error('Error:', error);
          this.sendingEmail = false;
          alert('❌ Error occurred. Contact: moorthyvinayaka77@gmail.com');
        });
      
    } else {
      // Mark all fields as touched to show validation errors
      Object.keys(this.enquiryForm.controls).forEach(key => {
        this.enquiryForm.get(key)?.markAsTouched();
      });
      
      // Scroll to first error
      const firstError = document.querySelector('.is-invalid');
      if (firstError) {
        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }

}
