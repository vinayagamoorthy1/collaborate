import { Injectable } from '@angular/core';
import emailjs from '@emailjs/browser';

@Injectable({
  providedIn: 'root'
})
export class EmailService {
  
  // Replace these with your EmailJS credentials from https://www.emailjs.com/
  private emailJsConfig = {
    serviceId: 'service_kcduas6',
    templateId: 'template_riy73fr',
    publicKey: 'A8O48zXLzi_GRm5w1'
  };
  
  private recipientEmail = 'iravigreenenergy@gmail.com';
  
  constructor() {
    if (this.isConfigured()) {
      emailjs.init(this.emailJsConfig.publicKey);
      console.log('✅ EmailJS ready - Emails go to:', this.recipientEmail);
    } else {
      console.warn('⚠️ Setup needed - See EMAILJS_SETUP_GUIDE.md');
    }
  }

  private isConfigured(): boolean {
    return this.emailJsConfig.serviceId !== 'YOUR_SERVICE_ID' &&
           this.emailJsConfig.templateId !== 'YOUR_TEMPLATE_ID' &&
           this.emailJsConfig.publicKey !== 'YOUR_PUBLIC_KEY';
  }

  async sendEnquiry(formData: any): Promise<{success: boolean, message: string}> {
    try {
      if (!this.isConfigured()) {
        return {
          success: false,
          message: '⚠️ Email Setup Required\n\nGo to https://www.emailjs.com/\nCreate account, get credentials\nUpdate src/app/services/email.ts\n\nContact: ' + this.recipientEmail
        };
      }

      const params = {
        to_email: this.recipientEmail,
        from_name: formData.name,
        from_email: formData.email,
        reply_to: formData.email,
        customer_mobile: formData.mobile,
        customer_age: formData.age,
        district: formData.district,
        city: formData.city,
        pincode: formData.pincode,
        solar_installation: formData.solarInstallation ? 'Yes' : 'No',
        kilowatt_needed: formData.kilowattNeeded || 'N/A',
        eb_service_number: formData.ebServiceNumber || 'N/A',
        registered_mobile: formData.registeredMobile || 'N/A',
        fabrication_enquiry: formData.fabricationEnquiry ? 'Yes' : 'No',
        length: formData.length || 'N/A',
        breadth: formData.breadth || 'N/A',
        material_type: formData.materialType || 'N/A',
        other_material: formData.otherMaterial || 'N/A',
        submission_date: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })
      };

      const response = await emailjs.send(
        this.emailJsConfig.serviceId,
        this.emailJsConfig.templateId,
        params
      );

      return {
        success: true,
        message: `✅ Success!\n\nEmail sent from: ${formData.email}\nTo: ${this.recipientEmail}\n\nWe'll contact you at ${formData.mobile}`
      };

    } catch (error: any) {
      console.error('Email failed:', error);
      return {
        success: false,
        message: `❌ Failed\n\nError: ${error.text || 'Network issue'}\n\nContact directly: ${this.recipientEmail}`
      };
    }
  }
}
